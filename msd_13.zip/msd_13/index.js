const express = require('express');
const fs = require('fs').promises;
const path = require('path');

const app = express();
app.use(express.json());

const DATA_FILE = path.join(__dirname, 'products.json');

// Helper functions for file operations

async function readProducts() {
    try {
        // Check if file exists, if not, initialize with an empty array
        try {
            await fs.access(DATA_FILE);
        } catch (err) {
            await fs.writeFile(DATA_FILE, '[]');
        }

        const data = await fs.readFile(DATA_FILE, 'utf-8');
        return JSON.parse(data || '[]');
    } catch (err) {
        console.error('Error reading file:', err);
        return [];
    }
}

async function writeProducts(products) {
    try {
        await fs.writeFile(DATA_FILE, JSON.stringify(products, null, 2));
    } catch (err) {
        console.error('Error writing file:', err);
    }
}

// Routes

app.get('/products', async (req, res) => {
    try {
        const products = await readProducts();
        res.json(products);
    } catch (err) {
        res.status(500).json({ error: 'Failed to retrieve products' });
    }
});

app.get('/products/instock', async (req, res) => {
    try {
        const products = (await readProducts()).filter(p => p.inStock);
        res.json(products);
    } catch (err) {
        res.status(500).json({ error: 'Failed to retrieve products' });
    }
});

app.post('/products', async (req, res) => {
    const { name, price, inStock } = req.body;

    if (!name || typeof price !== 'number' || typeof inStock !== 'boolean') {
        return res.status(400).json({ error: 'Invalid input data' });
    }

    try {
        const products = await readProducts();
        const newId = products.length ? Math.max(...products.map(p => p.id)) + 1 : 1;

        const newProduct = { id: newId, name, price, inStock };
        products.push(newProduct);
        await writeProducts(products);

        res.status(201).json(newProduct);
    } catch (err) {
        res.status(500).json({ error: 'Failed to add new product' });
    }
});

app.put('/products/:id', async (req, res) => {
    const id = parseInt(req.params.id);
    const { name, price, inStock } = req.body;

    try {
        const products = await readProducts();
        const productIndex = products.findIndex(p => p.id === id);

        if (productIndex === -1) {
            return res.status(404).json({ error: 'Product not found' });
        }

        const product = products[productIndex];
        if (name !== undefined) product.name = name;
        if (price !== undefined) product.price = price;
        if (inStock !== undefined) product.inStock = inStock;

        await writeProducts(products);
        res.json(product);
    } catch (err) {
        res.status(500).json({ error: 'Failed to update product' });
    }
});

app.delete('/products/:id', async (req, res) => {
    const id = parseInt(req.params.id);

    try {
        const products = await readProducts();
        const newProducts = products.filter(p => p.id !== id);

        if (newProducts.length === products.length) {
            return res.status(404).json({ error: 'Product not found' });
        }

        await writeProducts(newProducts);
        res.json({ message: Product with id ${id} deleted successfully });
    } catch (err) {
        res.status(500).json({ error: 'Failed to delete product' });
    }
});

// Start the server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(✅ Server running on http://localhost:${PORT});
});